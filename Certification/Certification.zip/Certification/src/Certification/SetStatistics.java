package Certification;

import java.util.List;

public class SetStatistics {
	
	public static void statistics() {
		List<Integer> numbers = List.of(4, 0, 5, 2, 7, 1, 8, 6, 9, 3);
		int max = -1;
		for (int i = 0; i < numbers.size(); i++) {
		    int number = numbers.get(i);
		    if (max < number) {
		        max = number;
		    }
		}
		System.out.println("Max: " + max); // Max: 9
	}
}
