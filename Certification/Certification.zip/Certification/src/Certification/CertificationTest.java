package Certification;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CertificationTest {

	@Test
	void testMain() {
		CertificationService certificationService = new CertificationService();
		assertNull(certificationService);
	}

}
