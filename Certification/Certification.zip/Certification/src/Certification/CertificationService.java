package Certification;

import java.io.IOException;

public class CertificationService {

	public static void main(String[] args) throws IOException {
		CertificationItem.certification();
		SetArrayList.getTxt();
		SetSearch.search();
		SetStatistics.statistics();
	}
}